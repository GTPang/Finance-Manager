# Finance Manager

Hi there! I am linking the important resources here. But the project is very simple to setup. 

## The Project Folder has 2 parts 

- Backend
- Frontend Project
- Database

### Database

Import the SQL Table in MySQL, I used MySQL - XAMPP Server, so my queries are written accordingly.

### Backend

Open the Backend Folder then run the following commands

open .env file and check the Database Host and other options

- npm start

### Frontend

Open the Project Folder. 

open the .env file and set the Base URL for the Backend Server.

npm i > npm start